export default function ArabicTicketsPage() {
  return <h1 className="text-center text-2xl mt-10">التذاكر (قريباً)</h1>;
}
