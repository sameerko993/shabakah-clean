export default function ContactPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Contact Us</h1>
      <p>Email: support@shabakahsport.com</p>
      <p>Phone: +962-123-456789</p>
    </div>
  );
}
