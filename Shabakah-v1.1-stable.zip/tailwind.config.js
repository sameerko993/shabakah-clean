export default function ArabicHome() {
  return (
    <main style={{ direction: "rtl", padding: "20px" }}>
      <h1>مرحباً بكم في شبكة ⚽</h1>
      <p>تابع أحدث المباريات، الترتيب، والأخبار باللغة العربية.</p>
    </main>
  );
}
