module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},   // ✅ correct plugin
    autoprefixer: {},
  },
};
